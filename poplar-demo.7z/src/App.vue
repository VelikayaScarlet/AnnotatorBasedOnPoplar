<template>
    <v-app>
        <router-view/>
    </v-app>
</template>

<script>
    export default {
        name: 'App'
    }
</script>

<style>
    @import '../static/typo.css';
</style>
